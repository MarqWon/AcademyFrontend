import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion"; // ✅ for motion.div

// ✅ Gradient colors for text
const gradientGlows = [
  "from-pink-500 via-red-500 to-yellow-500",
  "from-purple-500 via-indigo-500 to-blue-500",
  "from-green-400 via-emerald-500 to-teal-500",
  "from-orange-400 via-rose-500 to-pink-500",
];

// ✅ Shadows for cards
const glowShadows = [
  "shadow-lg shadow-pink-500/40",
  "shadow-lg shadow-purple-500/40",
  "shadow-lg shadow-green-500/40",
  "shadow-lg shadow-orange-500/40",
];

// ✅ Animation variant
const fadeInUp = {
  hidden: { opacity: 0, y: 30 },
  visible: (i = 1) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.2, duration: 0.6, ease: "easeOut" },
  }),
};

// ✅ Simple LazyImage (instead of missing component)
const LazyImage = ({ src, alt, className }) => (
  <img src={src} alt={alt} className={className} loading="lazy" />
);

const ProductCard = ({ product, delay = 0, index = 0 }) => {
  const navigate = useNavigate();
  const gradient = gradientGlows[index % gradientGlows.length];
  const glow = glowShadows[index % glowShadows.length];

  return (
    <motion.div
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true }}
      variants={fadeInUp}
      custom={delay + 1}
      whileHover={{ scale: 1.05, y: -6 }}
      transition={{ type: "spring", stiffness: 250, damping: 18 }}
      onClick={() => navigate(`/product/${product.id}`)}
      className={`relative group rounded-xl md:rounded-2xl overflow-hidden cursor-pointer border border-transparent backdrop-blur-lg transition duration-500 ${glow}`}
    >
      <LazyImage
        src={product.images[0]}
        alt={product.title}
        className="w-full h-[200px] sm:h-[240px] md:h-[280px] lg:h-[300px] object-contain transition-transform duration-700 group-hover:scale-110"
      />
      <div className="p-3 sm:p-4 text-center relative z-10">
        <h4
          className={`text-base sm:text-lg md:text-xl font-bold bg-gradient-to-r ${gradient} bg-clip-text text-transparent`}
        >
          {product.title}
        </h4>
        <p
          className={`text-xs sm:text-sm md:text-base font-medium bg-gradient-to-r ${gradient} bg-clip-text text-transparent`}
        >
          {product.category}
        </p>
      </div>
    </motion.div>
  );
};

export default ProductCard;
