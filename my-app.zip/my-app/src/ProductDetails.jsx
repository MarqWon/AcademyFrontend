import { useParams, useNavigate } from "react-router-dom";
import { products } from "./products";

const ProductDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const product = products.find((p) => p.id === parseInt(id));

  if (!product) {
    return (
      <div className="p-6 text-center">
        <h2 className="text-2xl text-red-500 font-bold">Product Not Found</h2>
        <button
          onClick={() => navigate("/")}
          className="mt-4 px-4 py-2 bg-blue-500 text-white rounded"
        >
          ⬅ Back to Products
        </button>
      </div>
    );
  }

  return (
    <div className="p-6">
      <button
        onClick={() => navigate("/")}
        className="mb-4 px-4 py-2 bg-blue-500 text-white rounded"
      >
        ⬅ Back
      </button>

      <h1 className="text-2xl font-bold">{product.title}</h1>
      <p className="text-gray-500">{product.category}</p>
      <img
        src={product.images[0]}
        alt={product.title}
        className="w-full h-80 object-contain my-4"
      />
      <p>{product.description}</p>
    </div>
  );
};

export default ProductDetails;
