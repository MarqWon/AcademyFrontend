import React from "react";
import { products } from "./products";
import ProductCard from "./ProductCard";


const Product = () => {
  return (
    <div className="p-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
      {products.map((product, index) => (
        <ProductCard
          key={product.id}
          product={product}
          delay={index * 0.2}
          index={index}
        />
      ))}
    </div>
  );
};

export default Product;
