// src/products.js
export const products = [
  // 1. Orthopedic / Joint Health
  {
    id: 1,
    category: "Orthopedic / Joint Health",
    title: "Tendo Qik",
    description:
      "Collagen Peptide Type I, Sodium Hyaluronate, Chondroitin Sulfate, Vitamin C – supportive tendon recovery formula.",
    images: ["https://i.postimg.cc/L6w1DSRV/Tendo-Qik-4-D.jpg"],
    composition:
      "Collagen Peptide Type I - 40MG, Sodium Hyaluronate - 30MG, Chondroitin Sulfate - 200MG, Vitamin C - 12.5MG Tablets.",
    fullDescription:
      "Collagen Peptide Type I, Sodium Hyaluronate, and Chondroitin Sulfate may help support tendon recovery and joint flexibility by nourishing connective tissues.",
    indication: "For early & recovering tendinopathies.",
  },
  {
    id: 2,
    category: "Orthopedic / Joint Health",
    title: "FlexiMove",
    description: "Glucosamine & MSM blend to support cartilage and joint mobility.",
    images: ["https://i.postimg.cc/yNW3qFsh/placeholder.jpg"],
    composition: "Glucosamine Sulfate - 500MG, MSM - 250MG, Boswellia Extract - 100MG.",
    fullDescription:
      "FlexiMove nourishes cartilage, improves joint flexibility, and reduces inflammation-related stiffness.",
    indication: "For osteoarthritis, cartilage wear, and stiff joints.",
  },
  {
    id: 3,
    category: "Orthopedic / Joint Health",
    title: "ArthroCare",
    description: "Herbal + mineral formulation for long-term joint support.",
    images: ["https://i.postimg.cc/yNW3qFsh/placeholder.jpg"],
    composition: "Ashwagandha - 200MG, Shallaki - 150MG, Zinc - 20MG.",
    fullDescription:
      "ArthroCare combines herbal extracts with minerals to reduce joint inflammation and support flexibility.",
    indication: "For chronic joint pain and inflammatory arthritis.",
  },

  // 2. Bone Health
  {
    id: 4,
    category: "Bone Health",
    title: "Osteo Plus",
    description: "Calcium, Vitamin D3, and Magnesium for maintaining strong and healthy bones.",
    images: ["https://i.postimg.cc/yNW3qFsh/placeholder.jpg"],
    composition: "Calcium Carbonate - 500MG, Vitamin D3 - 1000IU, Magnesium - 100MG.",
    fullDescription:
      "Osteo Plus supports bone mineral density, prevents osteoporosis, and promotes long-term skeletal strength.",
    indication: "For osteoporosis prevention and bone health support.",
  },
  {
    id: 5,
    category: "Bone Health",
    title: "BoneMax",
    description: "Triple-action mineral complex for strong and healthy bones.",
    images: ["https://i.postimg.cc/yNW3qFsh/placeholder.jpg"],
    composition: "Calcium Citrate - 600MG, Vitamin K2 - 100MCG, Boron - 3MG.",
    fullDescription:
      "BoneMax improves calcium absorption, reduces bone brittleness, and maintains bone strength.",
    indication: "For bone fractures, post-menopause bone care.",
  },
  {
    id: 6,
    category: "Bone Health",
    title: "D3 Vita",
    description: "High-strength Vitamin D3 capsules for bone and immune health.",
    images: ["https://i.postimg.cc/yNW3qFsh/placeholder.jpg"],
    composition: "Vitamin D3 - 5000IU softgel.",
    fullDescription:
      "D3 Vita maintains bone strength, improves calcium utilization, and supports immunity.",
    indication: "For vitamin D deficiency and weak bones.",
  },

  // 3. Cardiovascular Health
  {
    id: 7,
    category: "Cardiovascular Health",
    title: "CardioSafe",
    description: "Omega-3 fatty acids with Coenzyme Q10 to support heart health and circulation.",
    images: ["https://i.postimg.cc/yNW3qFsh/placeholder.jpg"],
    composition: "Omega-3 - 1000MG, Coenzyme Q10 - 100MG, Vitamin E - 30IU.",
    fullDescription:
      "CardioSafe helps maintain healthy cholesterol levels, supports cardiac output, and reduces oxidative stress.",
    indication: "For cholesterol management and cardiovascular health.",
  },
  {
    id: 8,
    category: "Cardiovascular Health",
    title: "CholestoCare",
    description: "Natural plant sterols to manage cholesterol and heart function.",
    images: ["https://i.postimg.cc/yNW3qFsh/placeholder.jpg"],
    composition: "Plant Sterols - 400MG, Niacin - 20MG.",
    fullDescription:
      "CholestoCare lowers LDL cholesterol and supports heart rhythm balance.",
    indication: "For high cholesterol and cardiovascular risk patients.",
  },
  {
    id: 9,
    category: "Cardiovascular Health",
    title: "HeartStrong",
    description: "Magnesium & Hawthorn for vascular relaxation and blood flow.",
    images: ["https://i.postimg.cc/yNW3qFsh/placeholder.jpg"],
    composition: "Magnesium - 200MG, Hawthorn Extract - 150MG, L-Arginine - 250MG.",
    fullDescription:
      "HeartStrong improves blood vessel flexibility, supports blood pressure regulation, and enhances circulation.",
    indication: "For hypertension and vascular weakness.",
  },

  // 4. Immunity
  {
    id: 10,
    category: "Immunity",
    title: "ImmunoMax",
    description: "Zinc, Vitamin C, and Echinacea blend for boosting natural immunity.",
    images: ["https://i.postimg.cc/yNW3qFsh/placeholder.jpg"],
    composition: "Vitamin C - 500MG, Zinc - 15MG, Echinacea Extract - 200MG.",
    fullDescription:
      "ImmunoMax strengthens the immune system and provides antioxidant protection against infections.",
    indication: "For boosting immunity and reducing infections.",
  },
  {
    id: 11,
    category: "Immunity",
    title: "ViraShield",
    description: "Elderberry & Vitamin D3 for seasonal immunity support.",
    images: ["https://i.postimg.cc/yNW3qFsh/placeholder.jpg"],
    composition: "Elderberry Extract - 300MG, Vitamin D3 - 2000IU.",
    fullDescription:
      "ViraShield helps the body fight viral infections and strengthens seasonal immune defenses.",
    indication: "For flu, colds, and seasonal protection.",
  },
  {
    id: 12,
    category: "Immunity",
    title: "Defenza",
    description: "Herbal immunity booster with Tulsi, Giloy, and Amla.",
    images: ["https://i.postimg.cc/yNW3qFsh/placeholder.jpg"],
    composition: "Tulsi - 200MG, Giloy - 250MG, Amla - 150MG.",
    fullDescription:
      "Defenza is a natural herbal blend that improves white blood cell response and immune resistance.",
    indication: "For weak immunity and frequent infections.",
  },

  // 5. Energy & Vitality
  {
    id: 13,
    category: "Energy & Vitality",
    title: "EnergyX",
    description: "B-Complex vitamins and Ginseng for daily energy and reduced fatigue.",
    images: ["https://i.postimg.cc/yNW3qFsh/placeholder.jpg"],
    composition: "Vitamin B1 - 10MG, B6 - 20MG, B12 - 100MCG, Ginseng - 100MG.",
    fullDescription:
      "EnergyX supports energy metabolism, reduces fatigue, and enhances focus.",
    indication: "For low energy and fatigue recovery.",
  },
  {
    id: 14,
    category: "Energy & Vitality",
    title: "VitaBoost",
    description: "Multivitamin and mineral complex for overall health and vitality.",
    images: ["https://i.postimg.cc/yNW3qFsh/placeholder.jpg"],
    composition: "Multivitamin + 12 minerals per tablet.",
    fullDescription:
      "VitaBoost provides daily nutritional support for active lifestyles and recovery.",
    indication: "For general weakness and nutrition gaps.",
  },
  {
    id: 15,
    category: "Energy & Vitality",
    title: "PowerUp",
    description: "Creatine & L-Carnitine formula for physical endurance.",
    images: ["https://i.postimg.cc/yNW3qFsh/placeholder.jpg"],
    composition: "Creatine Monohydrate - 3000MG, L-Carnitine - 500MG.",
    fullDescription:
      "PowerUp boosts athletic performance, increases stamina, and reduces recovery time.",
    indication: "For athletes and active individuals.",
  },

  // 6. Digestive Health
  {
    id: 16,
    category: "Digestive Health",
    title: "GastroEase",
    description: "Probiotics and enzymes for healthy digestion.",
    images: ["https://i.postimg.cc/yNW3qFsh/placeholder.jpg"],
    composition: "Probiotic blend - 5B CFU, Papain - 50MG, Amylase - 30MG.",
    fullDescription:
      "GastroEase improves digestion, reduces bloating, and supports gut health.",
    indication: "For indigestion, bloating, and poor gut flora.",
  },
  {
    id: 17,
    category: "Digestive Health",
    title: "LactoWell",
    description: "Lactase enzyme for lactose intolerance relief.",
    images: ["https://i.postimg.cc/yNW3qFsh/placeholder.jpg"],
    composition: "Lactase Enzyme - 4500 FCC units per capsule.",
    fullDescription:
      "LactoWell supports digestion of dairy, reducing gas, cramps, and discomfort.",
    indication: "For lactose intolerance.",
  },
  {
    id: 18,
    category: "Digestive Health",
    title: "HepatoCare",
    description: "Milk Thistle and B-Vitamins for liver detox and health.",
    images: ["https://i.postimg.cc/yNW3qFsh/placeholder.jpg"],
    composition: "Milk Thistle Extract - 300MG, Vitamin B Complex.",
    fullDescription:
      "HepatoCare supports liver detoxification, reduces toxin load, and improves metabolism.",
    indication: "For liver protection and detox support.",
  },
];
